import httpx
import os

FRESH_URL = os.getenv("FRESH_URL")
FRESH_API_KEY = os.getenv("FRESH_API_KEY")

class FreshClient:
    def __init__(self):
        self.base_url = FRESH_URL
        self.auth = (FRESH_API_KEY, "X")

    async def get(self, endpoint, params=None):
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{endpoint}", auth=self.auth, params=params)
            r.raise_for_status()
            return r.json()

    async def post(self, endpoint, data=None):
        async with httpx.AsyncClient() as client:
            r = await client.post(f"{self.base_url}{endpoint}", auth=self.auth, json=data)
            r.raise_for_status()
            return r.json()

    async def put(self, endpoint, data=None):
        async with httpx.AsyncClient() as client:
            r = await client.put(f"{self.base_url}{endpoint}", auth=self.auth, json=data)
            r.raise_for_status()
            return r.json()

fresh = FreshClient()
