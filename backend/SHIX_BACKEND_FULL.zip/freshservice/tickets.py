from .client import fresh

async def get_tickets_for_requester(requester_id: int):
    params = {"requester_id": requester_id}
    data = await fresh.get("/api/v2/tickets", params=params)
    return data.get("tickets", [])

async def create_ticket(subject: str, description: str, requester_id: int, priority=2):
    body = {
        "subject": subject,
        "description": description,
        "priority": priority,
        "requester_id": requester_id
    }
    return await fresh.post("/api/v2/tickets", data=body)
