import os
import requests
from requests.auth import HTTPBasicAuth

FRESHSERVICE_DOMAIN = os.getenv("FRESHSERVICE_DOMAIN")
FRESHSERVICE_API_KEY = os.getenv("FRESHSERVICE_API_KEY")

BASE_URL = f"https://{FRESHSERVICE_DOMAIN}.freshservice.com/api/v2"


def get_ticket(ticket_id: int):
    url = f"{BASE_URL}/tickets/{ticket_id}"

    response = requests.get(
        url,
        auth=HTTPBasicAuth(FRESHSERVICE_API_KEY, "X"),
        headers={"Content-Type": "application/json"},
        timeout=3  # 🔒 HARD TIMEOUT
    )

    response.raise_for_status()
    return response.json().get("ticket")
