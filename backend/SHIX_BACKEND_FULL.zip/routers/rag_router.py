from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from rag.rag_answer_engine import answer

router = APIRouter(prefix="/rag", tags=["RAG"])


class RagQuery(BaseModel):
    query: str


@router.post("/ask")
def rag_ask(payload: RagQuery):
    try:
        result = answer(payload.query)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"RAG engine failure: {str(e)}"
        )
