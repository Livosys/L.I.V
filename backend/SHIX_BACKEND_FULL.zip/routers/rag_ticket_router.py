from fastapi import APIRouter
from pydantic import BaseModel

from rag.rag_answer_engine import answer

router = APIRouter(
    prefix="/rag/ticket",
    tags=["rag-ticket"]
)


class TicketPayload(BaseModel):
    ticket_id: int
    subject: str
    description: str


@router.post("/analyze")
def analyze_ticket(payload: TicketPayload):
    try:
        # Build a single query string for RAG
        query = f"""
Ticket ID: {payload.ticket_id}
Subject: {payload.subject}
Description: {payload.description}
"""

        rag_result = answer(query)
        return rag_result

    except Exception as e:
        # IMPORTANT: return error instead of 500
        return {
            "error": "RAG ticket analysis failed",
            "exception": str(e)
        }
