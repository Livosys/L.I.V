from fastapi import APIRouter, Query
from services.freshservice_client import get_ticket
from services.controlled_ticket_fetcher import fetch_next_tickets

router = APIRouter(prefix="/freshservice", tags=["Freshservice"])


@router.get("/tickets/controlled")
def controlled_tickets(
    max: int = Query(1, ge=1, le=10),
    only_status: str = Query("closed")
):
    """
    Controlled, least-privilege, NEVER-500 endpoint
    """
    try:
        result = fetch_next_tickets(max_items=max, only_status=only_status)
        return result
    except Exception as e:
        # Absolute last-resort safety net
        return {
            "safe": True,
            "strategy": "controlled_id",
            "error": "controlled_fetch_failed",
            "detail": str(e)
        }


@router.get("/tickets/{ticket_id}")
def ticket(ticket_id: int):
    try:
        return get_ticket(ticket_id)
    except Exception as e:
        return {
            "error": "ticket_fetch_failed",
            "ticket_id": ticket_id,
            "detail": str(e)
        }
