from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/ai", tags=["AI"])

class ChatRequest(BaseModel):
    message: str

@router.post("/chat")
def chat(req: ChatRequest):
    """
    DEMO CHAT – kopplad till Assistent 4 (logik förenklad för demo)
    """
    user_message = req.message

    # Här kommer Assistent 4 + RAG in senare
    reply = (
        "🧠 SHIX AI (demo):\\n\\n"
        f"Jag har analyserat ditt ärende:\\n"
        f"\"{user_message}\"\\n\\n"
        "Detta liknar tidigare ärenden som ofta löses via standardåtgärd."
    )

    return {
        "reply": reply
    }
