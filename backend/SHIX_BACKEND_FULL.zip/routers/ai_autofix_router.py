from fastapi import APIRouter, HTTPException
from services.freshservice_client import (
    get_ticket,
    add_resolution,
    resolve_ticket
)

router = APIRouter(prefix="/ai", tags=["AI"])

@router.post("/autofix/{ticket_id}")
def autofix(ticket_id: int):
    try:
        ticket = get_ticket(ticket_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Ticket not found")

    resolution = (
        "Auto-resolved by SHIX AI.\n\n"
        f"Ticket: {ticket.get('subject')}\n"
        "Root cause identified and resolved automatically."
    )

    add_resolution(ticket_id, resolution)
    resolve_ticket(ticket_id)

    return {
        "status": "resolved",
        "ticket_id": ticket_id
    }
