from fastapi import APIRouter, Query
import requests
import os

router = APIRouter(prefix="/freshservice/user", tags=["freshservice-user"])

FRESH_DOMAIN = os.getenv("FRESHSERVICE_DOMAIN")
FRESH_API_KEY = os.getenv("FRESHSERVICE_API_KEY")

BASE_URL = f"https://{FRESH_DOMAIN}.freshservice.com/api/v2"

def fresh_get(path, params=None):
    r = requests.get(
        f"{BASE_URL}{path}",
        auth=(FRESH_API_KEY, "X"),
        params=params,
        timeout=20
    )
    r.raise_for_status()
    return r.json()

@router.get("/overview")
def user_overview(email: str = Query(...)):
    # 1. SÖK REQUESTER VIA SEARCH API (RÄTT SÄTT)
    search = fresh_get(
        "/search/requesters",
        params={"query": f"email:'{email}'"}
    )

    results = search.get("results", [])
    if not results:
        return {
            "exists": False,
            "user": None,
            "tickets": []
        }

    requester = results[0]
    requester_id = requester["id"]

    # 2. HÄMTA TICKETS FÖR REQUESTER
    tickets_data = fresh_get(
        "/tickets",
        params={"requester_id": requester_id}
    )

    tickets = [{
        "id": t["id"],
        "subject": t["subject"],
        "type": t.get("type"),
        "status": t.get("status"),
        "priority": t.get("priority"),
        "created_at": t.get("created_at")
    } for t in tickets_data.get("tickets", [])]

    return {
        "exists": True,
        "user": {
            "id": requester_id,
            "name": requester.get("name"),
            "email": requester.get("email")
        },
        "tickets": tickets
    }
