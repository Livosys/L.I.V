from fastapi import APIRouter

router = APIRouter(prefix="/rag", tags=["RAG"])

@router.get("/similar/{ticket_id}")
def get_similar_cases(ticket_id: int):
    # DEMO-DATA (ersätts senare med riktig RAG)
    return {
        "ticket_id": ticket_id,
        "similar_cases": [
            {
                "id": 101,
                "summary": "VPN not connecting after password reset",
                "resolution": "User logged out/in and VPN profile was refreshed"
            },
            {
                "id": 87,
                "summary": "Email sync issue on mobile",
                "resolution": "Removed and re-added Exchange account"
            },
            {
                "id": 64,
                "summary": "Laptop extremely slow",
                "resolution": "Disk cleanup + disabled startup apps"
            }
        ]
    }
