import json
import numpy as np
import os
from rank_bm25 import BM25Okapi

def save_vector_db(chunks, embeddings, path):
    data = []
    for chunk, emb in zip(chunks, embeddings):
        data.append({
            "text": chunk["text"],
            "source": chunk["source"],
            "embedding": emb
        })

    with open(path, "w") as f:
        json.dump(data, f)

    return True


def load_vector_db(path):
    if not os.path.exists(path):
        return []

    with open(path, "r") as f:
        raw = json.load(f)

    db = []
    for item in raw:
        db.append({
            "text": item["text"],
            "source": item["source"],
            "embedding": np.array(item["embedding"], dtype=float)
        })

    return db


def cosine(a, b):
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def hybrid_search(db, q_emb, q_text, top_k=5):
    # VECTOR SEARCH
    vec_scores = []
    for item in db:
        score = cosine(item["embedding"], q_emb)
        vec_scores.append((score, item))

    vec_scores.sort(key=lambda x: x[0], reverse=True)

    # BM25 TEXT SEARCH
    corpus = [item["text"].split() for item in db]
    bm25 = BM25Okapi(corpus)
    bm25_scores_values = bm25.get_scores(q_text.split())

    bm25_scores = [(bm25_scores_values[i], db[i]) for i in range(len(db))]
    bm25_scores.sort(key=lambda x: x[0], reverse=True)

    # HYBRID FUSION
    final = {}
    for s, item in vec_scores:
        final[item["text"]] = final.get(item["text"], 0) + float(s)

    for s, item in bm25_scores:
        final[item["text"]] = final.get(item["text"], 0) + float(s)

    combined = []
    for text, score in final.items():
        item = next(x for x in db if x["text"] == text)
        combined.append((score, item))

    combined.sort(key=lambda x: x[0], reverse=True)

    return combined[:top_k]
def search_similar(query: str, top_k: int = 5):
    """
    Simple wrapper used by rag_answer_engine.
    Loads vector DB and performs hybrid search.
    """

    DB_PATH = "data/vector_db.json"

    db = load_vector_db(DB_PATH)
    if not db:
        return []

    # VERY SIMPLE placeholder embedding (until real embeddings are added)
    # Uses zeros so system does not crash
    q_emb = np.zeros(len(db[0]["embedding"]), dtype=float)

    results = hybrid_search(db, q_emb, query, top_k=top_k)

    # Normalize output format
    output = []
    for score, item in results:
        output.append({
            "text": item["text"],
            "score": score,
            "source": item.get("source")
        })

    return output
