from openai import OpenAI
import os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def rerank(query, results):
    if not results:
        return None

    candidates = "\n\n".join(
        [f"[Candidate {i+1}]\nScore: {s}\nText: {item['text']}"
         for i, (s, item) in enumerate(results)]
    )

    prompt = f"""
You are a professional AI Re-Ranker. Select ONLY the best answer.

Query:
{query}

Candidates:
{candidates}

Return the single best candidate TEXT only.
"""

    resp = client.chat.completions.create(
        model="gpt-4.1",
        messages=[{"role": "user", "content": prompt}]
    )

    return resp.choices[0].message.content.strip()
