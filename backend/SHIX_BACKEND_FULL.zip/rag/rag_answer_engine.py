from datetime import datetime
from typing import List

from rag.vector_db import search_similar
from rag.llm_client import ask_llm


def build_prompt(query: str, chunks: List[dict]) -> str:
    context = "\n\n".join(
        f"- {c['text']}" for c in chunks
    )

    return f"""
You are answering a user question using historical IT support tickets.

Question:
{query}

Relevant historical context:
{context}

Answer clearly and concisely.
If the context is insufficient, say so.
"""


def answer(query: str) -> dict:
    chunks = search_similar(query, top_k=5)

    if not chunks:
        return {
            "answer": "No relevant historical tickets were found.",
            "used_chunks": [],
            "generated_at": datetime.utcnow().isoformat() + "Z"
        }

    prompt = build_prompt(query, chunks)
    llm_answer = ask_llm(prompt)

    return {
        "answer": llm_answer,
        "used_chunks": [
            {"id": c.get("id"), "score": c.get("score")}
            for c in chunks
        ],
        "generated_at": datetime.utcnow().isoformat() + "Z"
    }
