import re

def smart_chunk(text, source, chunk_size=300, overlap=50):
    words = re.split(r'\s+', text)
    chunks = []
    start = 0
    end = chunk_size

    while start < len(words):
        chunk_words = words[start:end]
        
        chunks.append({
            "text": " ".join(chunk_words),
            "source": source,
            "start_word": start,
            "end_word": end
        })

        start = end - overlap
        end = start + chunk_size

    return chunks
