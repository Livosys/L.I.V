from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

from routers.freshservice_router import router as freshservice_router
from routers.freshservice_user_router import router as freshservice_user_router
from routers.rag_router import router as rag_router
from routers.rag_ticket_router import router as rag_ticket_router

app = FastAPI(title="SHIX Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"status": "SHIX Backend running"}

@app.get("/health")
def health():
    return {"status": "ok", "service": "shix"}

# Always on
app.include_router(freshservice_router)
app.include_router(freshservice_user_router)

# RAG (explicit)
app.include_router(rag_router)
app.include_router(rag_ticket_router)

print("### SHIX MAIN LOADED FROM BACKEND ROOT ###")
